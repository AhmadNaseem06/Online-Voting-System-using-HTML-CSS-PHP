<?php
session_start();
if (!isset($_SESSION['userdata'])){

    header("location:../ " );
}

$userdata= $_SESSION['userdata'];
$groupsdata= $_SESSION['groupsdata'];
//  changing userstatus 
if($_SESSION['userdata']['status']==0){
    $status='<b style="color:red">Not Voted</b>';
}
else{
    $status='<b style="color:green">Voted</b>';

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <title>Online Voting sysytem -Dashboard
    </title>
    
</head>

<body>
    <div class="mainsection">
    <div class="container">
    <a href="../">   <button class="back-btn">  Back</button></a>
    <a href="logout.php"> <button class="logout-btn"> Logout</button></a>
        <h1>Online Voting System</h1>
        <hr>
        <!-- Your content goes here -->
    </div>


    <div class="profile">
    <img class="image" src="../uploads/<?php echo $userdata['photo']  ?>" height="100px"  width="100px" >
    <br><br>
    <b>Name:</b><?php   echo $userdata['name'] ?><br><br>
    <b>Mobile:</b> <?php   echo $userdata['mobile'] ?><br><br>
    <b>Adress:</b>  <?php   echo $userdata['adress'] ?><br><br>
    <b>Status:</b> <?php   echo $status ?><br><br>
    </div>
    <div class="group">
          <?php
     if($_SESSION['groupsdata']){
      for($i= 0;$i<count($groupsdata);$i++){
          ?>
            <div >

            <img  class="gimage" src="../uploads/<?php echo $groupsdata[$i]['photo']  ?>" height="100px"  width="100px">
            <b>Group Name: </b><?php echo $groupsdata[$i]['name'] ?> <br/> <br/>
            <b>Votes:  </b><?php echo $groupsdata[$i]['votes'] ?> <br/>
            <form method="post" action="../api/vote.php" > <!-- Pointing the form to a new PHP file to handle the vote -->
    <input type="hidden" name="gid" value="<?php echo $groupsdata[$i]['id']; ?>"><br/> <!-- Assuming each group has a unique 'id' -->
    <input type="hidden" name="gvotes" value="<?php echo $groupsdata[$i]['votes']; ?>"> <!-- Assuming the user has a unique 'id' -->
   <?php
      if($_SESSION['userdata']['status']  == 0){
      ?>
        <input type="submit" name="votebtn" value="Vote" id="votebtn">  <?php

      }
      else{
        ?>
        <button disabled name="votebtn" value="Vote" id="voted"> Voted <?php
      }


?>
   
   
    
</form>
            </div>
            <br/>
            <hr>

          <?php
      }
    }
  ?>
    </div>
    </div>
    
</body>
</html>