<?php
session_start();
include ('connect.php'); // Include your database connection script


$votes=$_POST['gvotes'];
$total_votes= $votes+1;
$gid = $conn->real_escape_string($_POST['gid']);
$userid = $conn->real_escape_string($_SESSION['userdata']['id']);


$update_votes = mysqli_query($conn,"UPDATE user SET votes = '$total_votes' WHERE id = '$gid'");

$update_user_status =mysqli_query($conn,"UPDATE user SET status =1   WHERE id = '$userid'");

if($update_votes  and $update_user_status  ){
$groups = mysqli_query($conn,"SELECT  * from user WHERE role = 2");
$groupsdata=mysqli_fetch_all($groups, MYSQLI_ASSOC); 
$_SESSION['userdata']['status']=1;
$_SESSION['groupsdata']=$groupsdata;
echo 
'    <script>

    alert("voting success");
    window.location="../routes/dashboard.php";
    </script> ';
}

else{
    echo 
'    <script>

    alert("some error accured");
    window.location="../routes/dashboard.php";
    </script> ';
}
?>