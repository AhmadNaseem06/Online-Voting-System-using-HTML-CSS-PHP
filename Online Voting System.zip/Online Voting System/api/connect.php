<?php
$conn=mysqli_connect("localhost","root","","voting");
//  or die("Couldn't connect to database");

if($conn){
    echo "connection successfully";
}
else {
    echo "connection failed";
}

?>