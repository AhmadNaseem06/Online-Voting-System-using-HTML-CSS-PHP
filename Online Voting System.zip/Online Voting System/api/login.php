<?php
session_start();  //starting session

include 'connect.php';  //including the connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") //checking if type is Post

{
    // Get the data from the POST request
    $mobile = $_POST['mobile'];  //gettig the data from form  mobile no
    $password =$_POST['password'];// getting the password fromform
    $role = $_POST['role']; //getting the role from for,

    //query to select the data frpm data base which is input  in for,
    $check = mysqli_query($conn,"SELECT * FROM user WHERE mobile = '$mobile' AND password = '$password' AND role = '$role'");
     

    if(mysqli_num_rows($check)>0)  //condition to check if there is atleast one row of data 
    
    {
            $userdata=mysqli_fetch_array($check);  // fetching data
            $groups= mysqli_query($conn,"SELECT * FROM user WHERE role = 2");  //query to retrieve groups data             
            $groupsdata=mysqli_fetch_all($groups, MYSQLI_ASSOC); //fetching groups data

            //creating session variables  these are variable so we can acces the data form eny page
            $_SESSION['userdata']=$userdata;
            $_SESSION['groupsdata']=$groupsdata;
                     //openng the dashboard page
                     
            echo '
            <script>
                  window.location="../routes/dashboard.php";  
                

            </script> ';
    } 
     //else cobdition if login is not success
    else{
        echo '
        <script>
        alert("Invalid credentials");
        window.location="../";
        </script> ';
    }
}
?>