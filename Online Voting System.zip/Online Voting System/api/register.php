<?php
include 'connect.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data from POST request
    $name = $conn->real_escape_string($_POST['name']);
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $password = $conn->real_escape_string($_POST['password']);
    $confirm_password = $conn->real_escape_string($_POST['confirm_password']);
    $address = $conn->real_escape_string($_POST['address']);
    $image= $_FILES['photo']['name'];  //gtiing image
    $tmp_name= $_FILES['photo']['tmp_name'];
    $role = $conn->real_escape_string($_POST['role']);
    $status = 0; 
    $votes = 0; // Initialize votes to 0 for new registration
  
   
    //password encrypt 
// $passwordEncrypted = password_hash($password, PASSWORD_DEFAULT);


    //handling file upoad
   

    if ($password== $confirm_password)  //checking if the password and confirm password match 
    
    {
    move_uploaded_file($tmp_name, "../uploads/$image");  //uploading mage file to uplaods folder
    //inserting the data into datbase
    $insert= mysqli_query($conn,"INSERT INTO user (name, mobile, password, adress, photo, role, status, votes) VALUES ('$name', '$mobile', '$password', '$address', '$image', '$role', '$status', '$votes')");
      if($insert)  //checking if data is inserted successfully hen open the login page
      
       {
        echo '
        <script>

        alert("Registeration success");
        window.location="../";
        </script> '; } 
        else   //if not then  open register page 
        {
            echo '
            <script>
    
            alert("Problem accured);
            window.location="../routes/register.html"";
            </script> ';
        }

    }
    //if passworrd does not match the open the register oage again with messsage
    else{
        echo '
        <script>

        alert("Password does not match");
        window.location="../routes/register.html";
        </script>
        
        
        ';
    }
}

?>